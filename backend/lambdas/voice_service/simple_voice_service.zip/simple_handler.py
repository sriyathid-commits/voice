"""
Simplified Voice Service Lambda Handler
Works with only boto3 (pre-installed in Lambda)
"""
import json
import boto3
import base64
from datetime import datetime

# Initialize AWS clients
transcribe = boto3.client('transcribe', region_name='ap-south-1')
bedrock = boto3.client('bedrock-runtime', region_name='ap-south-1')
polly = boto3.client('polly', region_name='ap-south-1')
s3 = boto3.client('s3', region_name='ap-south-1')

def lambda_handler(event, context):
    """
    Simple Lambda handler for voice processing
    """
    print(f"Event: {json.dumps(event)}")
    
    try:
        # Handle different event types
        if event.get('httpMethod') == 'POST' and '/voice/query' in event.get('path', ''):
            return handle_voice_query(event)
        elif event.get('httpMethod') == 'GET' and '/health' in event.get('path', ''):
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({'status': 'healthy', 'service': 'voice-service'})
            }
        else:
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'message': 'Voice Service is running',
                    'endpoints': ['/voice/query', '/health']
                })
            }
            
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'error': str(e),
                'message': 'Internal server error'
            })
        }

def handle_voice_query(event):
    """
    Handle voice query - simplified version
    """
    try:
        # For now, return a test response
        # In production, this would process the audio
        
        response_data = {
            'user_text': 'Test transcription',
            'response_text': 'नमस्ते! मैं आपकी मदद के लिए यहाँ हूँ। कृपया अपना सवाल पूछें।',
            'language': 'hi',
            'session_id': f"session-{datetime.now().timestamp()}",
            'status': 'success',
            'message': 'Voice service is working! (Test mode - real AI integration pending dependency fix)'
        }
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            'body': json.dumps(response_data)
        }
        
    except Exception as e:
        print(f"Error in handle_voice_query: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'error': str(e),
                'message': 'Error processing voice query'
            })
        }
